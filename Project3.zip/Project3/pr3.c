#include <linux/module.h>
#include <linux/version.h>
#include <linux/kernel.h>
#include <linux/types.h>
#include <linux/kdev_t.h>
#include <linux/fs.h>
#include <linux/device.h>
#include <linux/cdev.h>
#include <linux/uaccess.h>
#include <linux/random.h>

#define sizeOfNum sizeof(int)

static dev_t first; // Global variable for the first device number
static struct cdev c_dev; // Global variable for the character device structure
static struct class *cl; // Global variable for the device class

static int my_open(struct inode *i, struct file *f)
{
	printk(KERN_INFO "Driver: open()\n");
	return 0;
}

static int my_close(struct inode *i, struct file *f)
{
	printk(KERN_INFO "Driver: close()\n");
	return 0;
}

static ssize_t my_read(struct file *f, char __user *buf, size_t len, loff_t *off)
{
	int num;

	if(*off >= sizeOfNum)
		return 0; 

	printk(KERN_INFO "Driver: read()\n");

	get_random_bytes(&num, sizeOfNum);

	if (copy_to_user(buf, &num, sizeOfNum) != 0) {
		printk("Fail to return to user");
		return -EFAULT;
	} 

	*off += sizeOfNum;

	return sizeOfNum; 
}

static struct file_operations pugs_fops =
{
	.owner = THIS_MODULE,
	.open = my_open,
	.release = my_close,
	.read = my_read,
};

static int __init project3_init(void) /* Constructor */
{
	printk(KERN_INFO "Project 3 registered");

	if (alloc_chrdev_region(&first, 0, 1, "Shweta") < 0)
	{
		printk("Fail to alloc major");
		return -1;
	}

	if ((cl = class_create(THIS_MODULE, "chardrv")) == NULL)
	{
		printk("Fail to create device class");
		unregister_chrdev_region(first, 1);
		return -1;
	}

	if (device_create(cl, NULL, first, NULL, "abc") == NULL)
	{
		printk("Fail to create device file");
		class_destroy(cl);
		unregister_chrdev_region(first, 1);
		return -1;
	}

	cdev_init(&c_dev, &pugs_fops);

	if (cdev_add(&c_dev, first, 1) == -1)
	{
		printk("Fail to add character device structure to VFS");
		device_destroy(cl, first);
		class_destroy(cl);
		unregister_chrdev_region(first, 1);
		return -1;
	}

	return 0;
}

static void __exit project3_exit(void) /* Destructor */
{
	cdev_del(&c_dev);
	device_destroy(cl, first);
	class_destroy(cl);
	unregister_chrdev_region(first, 1);
	printk(KERN_INFO "Project 3 unregistered");
}

module_init(project3_init);
module_exit(project3_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("19127265 - 19127338 - 19127542");
MODULE_DESCRIPTION("Project 3 - HDH - 19CLC4");
