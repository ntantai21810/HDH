#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>

int main() {
	int fd, num;

	fd = open("/dev/abc", O_RDWR);

	if (fd < 0) {
		printf("Cannot open module \n");
		return -1;
	}

	read(fd, &num, sizeof(num));

	printf("%d \n", num);

	return 0;
}
